const signin = document.getElementById("sign-in");
const signoutBtn = document.getElementById("sign-out");
const textUserInfo = document.getElementById("accountBtn");
const _signinTab = document.querySelector("#signin_tab");
const _signupTab = document.querySelector("#signup_tab");
const inputSignupUser = document.getElementById("user");
const inputSignupPass = document.getElementById("pass");
const inputAddress = document.getElementById("address");
const inputEmail = document.getElementById("email");
const signupBtn = document.getElementById("signup_Btn");
const inputSigninUser = document.getElementById("user1");
const inputSigninPass = document.getElementById("pass1");
const signinBtn = document.getElementById("signin_Btn");
const closeBtns = document.querySelectorAll(".closeBtn");
const infoName = document.getElementById("infoName");
const infoBtn = document.getElementById("infoBtn");
const historyBuy = document.getElementById("historyBuyBtn");
const infoUser = document.getElementById("user_account");
const infoPass = document.getElementById("pass_account");
const infoEmail = document.getElementById("email_account");
const infoAddress = document.getElementById("address_account");
const edit_User = document.querySelector("#edit_user");
const edit_Pass = document.querySelector("#edit_pass");
const edit_Email = document.querySelector("#edit_email");
const edit_Address = document.querySelector("#edit_address");
const saveInfo = document.querySelector(".saveInfo");
const saveInfo1 = document.querySelector(".saveInfo1");
const saveInfo2 = document.querySelector(".saveInfo2");
const saveInfo3 = document.querySelector(".saveInfo3");
const _checkPass = document.querySelector("#check_pass");
const oldPass = document.querySelector("#old_pass");
const newPass = document.querySelector("#new_pass");


function _getAccounts() {
    return JSON.parse(localStorage.getItem("accounts")) || [];
}

function _saveAccounts(accounts) {
    localStorage.setItem("accounts", JSON.stringify(accounts));
}

function _getCurrentUser() {
    return sessionStorage.getItem("currentUser");
}

function _isLogged() {
    return _getCurrentUser() !== null;
}

function show(element, type = "block") {
    element.style.display = type;
}

function hide(element) {
    element.style.display = "none";
}



function _update() {
    if (_isLogged()) {
        hide(signin);
        infoName.textContent = _getCurrentUser();
        show(textUserInfo);
    } else {
        show(signin);
        hide(textUserInfo);
    }
}

function open_signinTab() {
    show(_signinTab, "flex");
    hide(_signupTab);
}

function open_signupTab() {
    show(_signupTab, "flex");
    hide(_signinTab);
}

function _closeAllTabs() {
    hide(_signinTab);
    hide(_signupTab);
    hide(_checkPass);
    history.replaceState(null, "", location.pathname + location.search);
}

function _hashChange() {
    const accountSection = document.getElementById("account");
    if (location.hash === "#account") {
        if (_isLogged()) _showinfo();
        return;
    }
    accountSection.hidden = true;

    const historyBuySection = document.getElementById("history");
    if (location.hash === "#history") {
        if (_isLogged()) _showhistory();
        return;
    }
    historyBuySection.hidden = true;

    if (_isLogged()) return;
    if (location.hash === "#signup_tab")
        open_signupTab();
    else if (location.hash === "#signin_tab")
        open_signinTab();
}

window.addEventListener("hashchange", _hashChange);

function _signup() {
    const username = inputSignupUser.value.trim();
    const password = inputSignupPass.value.trim();
    const email = inputEmail.value.trim();
    const address = inputAddress.value.trim();
    if (username === "" || password === "" || email === "" || address === "") {
        alert("Vui lòng nhập đầy đủ thông tin.");
        return;
    }
    const accounts = _getAccounts();
    const isUsernameTaken = accounts.some(function (acc) {
        return acc.username === username;
    });
    if (isUsernameTaken) {
        alert("Username đã tồn tại");
        return;
    }
    const isEmailTaken = accounts.some(function (acc) {
        return acc.email === email;
    });
    if (isEmailTaken) {
        alert("Email đã tồn tại");
        return;
    }
    const newAccount = {
        id: crypto.randomUUID(),
        username: username,
        password: password,
        email: email,
        address: address,
        locked: false
    };
    accounts.push(newAccount);
    _saveAccounts(accounts);

    alert("Đăng ký thành công.");
    _closeAllTabs();
    open_signinTab();
}


function _signin() {
    const username = inputSigninUser.value.trim();
    const password = inputSigninPass.value.trim();
    if (username === "" || password === "") {
        alert("Vui lòng nhập đầy đủ thông tin.");
        return;
    }
    const accounts = _getAccounts();
    const account = accounts.find(function (acc) {
        return acc.username === username && acc.password === password;
    });
    if (!account) {
        alert("Sai tài khoản hoặc mật khẩu.");
        return;
    }

    if (account.locked) {
        alert("Tài khoản của bạn đã bị khóa.");
        return;
    }
    //ghi lại tài khoản đang đăng nhập
    sessionStorage.setItem("currentUser", account.username);
    sessionStorage.setItem("currentUserId", account.id);
    _closeAllTabs();
    location.reload();
}

//hiện thông tin
function _showinfo() {
    document.getElementById("chi-tiet-san-pham").hidden = true;
    document.getElementById("san-pham").hidden = true;
    document.getElementById("account").hidden = false;
    document.getElementById("history").hidden = true;
    const accounts = _getAccounts();
    const account = accounts.find(function (acc) {
        return acc.id === sessionStorage.getItem("currentUserId");
    });
    infoUser.value = account.username;
    infoPass.value = account.password;
    infoEmail.value = account.email;
    infoAddress.value = account.address;

}
//hiện lịch sử mua
function _showhistory() {
    document.getElementById("chi-tiet-san-pham").hidden = true;
    document.getElementById("san-pham").hidden = true;
    document.getElementById("account").hidden = true;
    document.getElementById("history").hidden = false;
}
//đăng xuất
function _signout() {
    sessionStorage.removeItem("currentUser");
    sessionStorage.removeItem("currentUserId");
    location.reload();
}


//click
signin.addEventListener("click", open_signinTab);
edit_User.addEventListener("click", function () {
    infoUser.disabled = false;
    saveInfo.style.display = "block";
    infoEmail.disabled = true;
    saveInfo2.style.display = "none";
    infoAddress.disabled = true;
    saveInfo3.style.display = "none";
    infoPass.disabled = true;
    saveInfo1.style.display = "none";
});
edit_Pass.addEventListener("click", function () {
    infoPass.disabled = false;
    show(_checkPass, "flex");
    saveInfo1.style.display = "block";

    saveInfo.style.display = "none";
    infoEmail.disabled = true;
    saveInfo2.style.display = "none";
    infoAddress.disabled = true;
    saveInfo3.style.display = "none";
});
function _saveEdit(accounts) {
    localStorage.setItem("accounts", JSON.stringify(accounts));
    infoUser.disabled = true;
    saveInfo.style.display = "none";
    infoEmail.disabled = true;
    saveInfo2.style.display = "none";
    infoAddress.disabled = true;
    saveInfo3.style.display = "none";
    infoPass.disabled = true;
    saveInfo1.style.display = "none";
}
edit_Email.addEventListener("click", function () {
    infoUser.disabled = true;
    saveInfo.style.display = "none";
    infoEmail.disabled = false;
    saveInfo2.style.display = "block";
    infoAddress.disabled = true;
    saveInfo3.style.display = "none";
    infoPass.disabled = true;
    saveInfo1.style.display = "none";
});
edit_Address.addEventListener("click", function () {
    infoUser.disabled = true;
    saveInfo.style.display = "none";
    infoEmail.disabled = true;
    saveInfo2.style.display = "none";
    infoAddress.disabled = false;
    saveInfo3.style.display = "block";
    infoPass.disabled = true;
    saveInfo1.style.display = "none";
});
saveInfo.addEventListener("click", function () {
    const username = infoUser.value.trim();


    if (username === "") {
        alert("Không được để trống.");
        return;
    }

    const accounts = _getAccounts();
    const isUsernameTaken = accounts.some(function (acc) {
        return acc.username === username && acc.id !== sessionStorage.getItem("currentUserId");
    });
    if (isUsernameTaken) {
        alert("Username đã tồn tại.");
        return;
    }
    const account = accounts.find(function (acc) {
        return acc.id === sessionStorage.getItem("currentUserId");
    });
    account.username = username;
    _saveEdit(accounts);
    sessionStorage.setItem("currentUser", username);
    infoName.textContent = username;

});
saveInfo1.addEventListener("click", function () {
    const accounts = _getAccounts();
    const account = accounts.find(function (acc) {
        return acc.id === sessionStorage.getItem("currentUserId");
    });
    if (oldPass.value !== account.password) {
        alert("Sai mật khẩu!");
        return;
    }
    const password = newPass.value.trim();
    if (password === "") {
        alert("Không được để trống.");
        return;
    }
    account.password = password;
    alert("Đã đổi mật khẩu thành công.");
    hide(_checkPass);
    _saveEdit(accounts);
});
saveInfo2.addEventListener("click", function () {
    const email = infoEmail.value.trim();
    const accounts = _getAccounts();
    if (email === "") {
        alert("Không được để trống.");
        return;
    }

    const isEmailTaken = accounts.some(function (acc) {
        return acc.email === email && acc.id !== sessionStorage.getItem("currentUserId");
    });
    if (isEmailTaken) {
        alert("Email đã tồn tại.");
        return;
    }
    const account = accounts.find(function (acc) {
        return acc.id === sessionStorage.getItem("currentUserId");
    });
    account.email = email;
    _saveEdit(accounts);

});
saveInfo3.addEventListener("click", function () {
    const address = infoAddress.value.trim();
    if (address === "") {
        alert("Không được để trống.");
        return;
    }
    const accounts = _getAccounts();
    const account = accounts.find(function (acc) {
        return acc.id === sessionStorage.getItem("currentUserId");
    });
    account.address = address;
    _saveEdit(accounts);


});

for (const btn of closeBtns) {
    btn.addEventListener("click", _closeAllTabs);
}

signupBtn.addEventListener("click", _signup);
signinBtn.addEventListener("click", _signin);
signoutBtn.addEventListener("click", _signout);



_hashChange();
//load lại giao diện
_update();